﻿<!--
  Sync Impact Report: v0.0.0 → v1.0.0
  - Modified principles: all 5 placeholders filled with project-specific principles
  - Added sections: Technology Stack & Constraints, Development Workflow & Quality Gates
  - Removed sections: none
  - Templates requiring updates:
    - .specify/templates/plan-template.md: ✅ No changes needed — Constitution Check section is generic
    - .specify/templates/spec-template.md: ✅ No changes needed — spec format is independent of constitution
    - .specify/templates/tasks-template.md: ✅ No changes needed — task format is independent of constitution
  - Follow-up TODOs: none
-->

# Web Calculator Constitution

## Core Principles

### I. 纯前端零依赖 (Pure Frontend, Zero Dependencies)

The calculator MUST be implemented entirely in pure HTML5, CSS3, and JavaScript (ES6+)
without any external libraries, frameworks, or runtime dependencies. No build tools,
package managers, or preprocessors are permitted. The application MUST run directly
from the filesystem or any static web server with zero setup.

### II. 响应式设计 (Responsive Design)

The calculator interface MUST render correctly and remain fully usable across desktop
(≥1024px), tablet (≥768px), and mobile (≥320px) viewports without horizontal
scrolling. Layout MUST use CSS Grid and/or Flexbox. Font sizes, button spacing, and
interactive targets MUST scale proportionally.

### III. 计算准确性 (Computational Accuracy)

All arithmetic operations (addition, subtraction, multiplication, division) MUST
produce mathematically correct results. Floating-point precision issues MUST be
handled explicitly (e.g., rounding to a reasonable precision). Division by zero
MUST be caught and displayed as a user-friendly error message rather than crashing
or showing `Infinity`.

### IV. 输入灵活性 (Input Flexibility)

Users MUST be able to operate the calculator through two mutually independent input
channels: (a) mouse/touch clicks on on-screen buttons, and (b) keyboard input via
physical keystrokes. Keyboard support MUST include number keys, operator keys
(`+`, `-`, `*`, `/`), `Enter`/`=` for evaluation, `Backspace` for undo, `Escape`/`Delete`
for clear, and `.` for decimal input. Key mappings MUST be clearly discoverable.

### V. 简洁与可维护性 (Simplicity & Maintainability)

Code MUST be clean, well-structured, and self-documenting. Apply YAGNI — implement
only the features explicitly specified. CSS MUST use meaningful class names and
avoid deep selector chains. JavaScript MUST be organized into clear logical
sections (display, operations, keyboard handling, event binding). Avoid
unnecessary abstraction or premature optimization.

## Technology Stack & Constraints

**Stack**: HTML5 (semantic markup) + CSS3 (Grid/Flexbox layout, custom properties
for theming) + JavaScript ES6+ (vanilla, no transpilation).

**File Structure**: All source code MUST be contained in a single `index.html` file
(embedded `<style>` and `<script>`) OR up to three co-located files
(`index.html`, `style.css`, `script.js`) at the project root. No build step required.

**Browser Support**: MUST target the latest two versions of Chrome, Firefox, Safari,
and Edge. No legacy browser support required.

## Development Workflow & Quality Gates

1. All arithmetic operations MUST be manually verified against known test cases
   (e.g., `0.1 + 0.2 = 0.3`, `7 / 0 = Error`).
2. Responsive layout MUST be validated at 320px, 768px, and 1280px widths.
3. Every keyboard shortcut MUST be tested against its on-screen button counterpart.
4. All error states (division by zero, malformed expressions) MUST display
   gracefully without console-only errors.
5. Code MUST parse without errors in the browser console before submission.

## Governance

This constitution supersedes all informal practices. Amendments require documenting
the rationale in the Sync Impact Report section and updating the version number.
All features MUST be verified against the five core principles before acceptance.

**Version**: 1.0.0 | **Ratified**: 2026-07-24 | **Last Amended**: 2026-07-24